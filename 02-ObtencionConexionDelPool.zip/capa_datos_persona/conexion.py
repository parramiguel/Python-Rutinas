from logger_base import log
from psycopg_pool import ConnectionPool


class Conexion:
    _pool = ConnectionPool(
        conninfo="host=127.0.0.1 port=5432 dbname=test_db user=postgres password=admin",
        min_size=1,
        max_size=5,
        timeout=5
    )

    @classmethod
    def obtener_conexion(cls):
        return cls._pool.connection()


if __name__ == '__main__':
    Conexion._pool.check()
    log.debug('Pool de conexiones verificado correctamente.')

    # Caso con with, donde se reutilizan las conexiones
    for i in range(10):  # Pide 10 conexiones, pero se liberan automáticamente
        with Conexion.obtener_conexion() as conexion:
            log.debug(f'Conexión #{i + 1} abierta y cerrada: id={id(conexion)}')

    Conexion._pool.close()
    log.debug('Pool de conexiones cerrado correctamente.')

    # Caso sin with, se agotan las conexiones si se suparan
    # pero se tiene que usar:  return cls._pool.getconn()
    #conexiones = []
    # try:
    #     for i in range(6):  # intenta obtener más de 5 conexiones sin liberarlas
    #         conexion = Conexion.obtener_conexion()
    #         conexiones.append(conexion)
    #         log.debug(f'Conexión #{i + 1} obtenida: id={id(conexion)}')
    # except Exception as e:
    #     log.error(f'⚠️ Error al obtener conexión #{i + 1}: {e}')