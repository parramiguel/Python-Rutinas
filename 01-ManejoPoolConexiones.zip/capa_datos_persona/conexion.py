from logger_base import log
from psycopg_pool import ConnectionPool


class Conexion:
    _pool = ConnectionPool(
        conninfo="host=127.0.0.1 port=5432 dbname=test_db user=postgres password=admin",
        min_size=1,
        max_size=5,
        timeout=5
    )

    @classmethod
    def obtener_conexion(cls):
        return cls._pool.connection()

if __name__ == '__main__':
    Conexion._pool.check()
    log.debug('Pool de conexiones verificado correctamente.')

    with Conexion.obtener_conexion() as conexion:
        log.debug(f'Conexión abierta exitosamente: {conexion.info.dsn}')
    Conexion._pool.close()  # cerrar el pool manualmente