from logger_base import log
import psycopg

class Conexion:
    _DATABASE = 'test_db'
    _USERNAME = 'postgres'
    _PASSWORD = 'admin'
    _DB_PORT = '5432'
    _HOST = '127.0.0.1'

    @classmethod
    def obtener_conexion(cls):
        return psycopg.connect(
            host=cls._HOST,
            user=cls._USERNAME,
            password=cls._PASSWORD,
            port=cls._DB_PORT,
            dbname=cls._DATABASE
        )

if __name__ == '__main__':
    with Conexion.obtener_conexion() as conexion:
        log.debug(f'Conexión abierta exitosamente: {conexion.info.dsn}')

